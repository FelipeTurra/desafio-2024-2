package desafio.unoesc.fullstack.controllers;

import org.springframework.web.bind.annotation.*;
import desafio.unoesc.fullstack.models.Product;
import desafio.unoesc.fullstack.services.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // Página de listagem de produtos
    @GetMapping
    public String listProducts(Model model) {
        List<Product> products = productService.findAll();
        model.addAttribute("products", products);
        return "product-list"; // Página HTML para listar produtos
    }

    // Página de formulário para adicionar novo produto
    @GetMapping("/new")
    public String newProductForm(Model model) {
        model.addAttribute("product", new Product());
        return "product-form"; // Página HTML para cadastrar novo produto
    }

    // Salvar novo produto
    @PostMapping
    public String saveProduct(@ModelAttribute Product product, RedirectAttributes redirectAttributes) {
        try {
            productService.save(product);
            redirectAttributes.addFlashAttribute("message", "Produto salvo com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Erro ao salvar produto: " + e.getMessage());
        }
        return "redirect:/products";
    }

    // Página de formulário para editar produto
    @GetMapping("/edit/{id}")
    public String editProductForm(@PathVariable Long id, Model model) {
        Product product = productService.findById(id).orElseThrow(() -> new RuntimeException("Produto não encontrado"));
        model.addAttribute("product", product);
        return "product-form"; // Página HTML para editar produto
    }

    // Atualizar produto
    @PostMapping("/update/{id}")
    public String updateProduct(@PathVariable Long id, @ModelAttribute Product product, RedirectAttributes redirectAttributes) {
        try {
            productService.update(id, product);
            redirectAttributes.addFlashAttribute("message", "Produto atualizado com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Erro ao atualizar produto: " + e.getMessage());
        }
        return "redirect:/products";
    }

    // Excluir produto
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            productService.delete(id);
            redirectAttributes.addFlashAttribute("message", "Produto excluído com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Erro ao excluir produto: " + e.getMessage());
        }
        return "redirect:/products";
    }

    // Ressincronizar dados do produto
    @GetMapping("/resync/{id}")
    public String resyncProduct(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            productService.resyncProduct(id);
            redirectAttributes.addFlashAttribute("message", "Produto ressincronizado com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Erro ao ressincronizar produto: " + e.getMessage());
        }
        return "redirect:/products";
    }
}

