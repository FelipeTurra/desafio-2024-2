package desafio.unoesc.fullstack.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import desafio.unoesc.fullstack.models.Brand;
import desafio.unoesc.fullstack.services.BrandService;

@Controller
@RequestMapping("/brands")
public class BrandController {

    @Autowired
    private BrandService brandService;

    @GetMapping
    public String listBrands(Model model) {
        model.addAttribute("brands", brandService.findAll());
        return "brand-list"; // Mapeia para brand-list.html
    }

    @GetMapping("/new")
    public String showBrandForm(Model model) {
        model.addAttribute("brand", new Brand());
        return "brand-form"; // Mapeia para brand-form.html
    }

    @PostMapping("/save")
    public String saveBrand(@ModelAttribute Brand brand) {
        brandService.save(brand);
        return "redirect:/brands";
    }

    @GetMapping("/edit/{id}")
    public String showEditBrandForm(@PathVariable Long id, Model model) {
        model.addAttribute("brand", brandService.findById(id));
        return "brand-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteBrand(@PathVariable Long id) {
        brandService.delete(id);
        return "redirect:/brands";
    }
}
