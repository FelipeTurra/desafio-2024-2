package desafio.unoesc.fullstack.services;

import org.springframework.stereotype.Service;
import desafio.unoesc.fullstack.models.Product;
import desafio.unoesc.fullstack.repositories.ProductRepository;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // Listar todos os produtos
    public List<Product> findAll() {
        return productRepository.findAll();
    }

    // Buscar produto por ID
    public Optional<Product> findById(Long id) {
        return productRepository.findById(id);
    }

    // Salvar um novo produto
    public Product save(Product product) {
        // Consumir a API externa para complementar informações do produto
        RestTemplate restTemplate = new RestTemplate();
        String apiUrl = "https://dummyjson.com/products/" + product.getId();
        Product apiProduct = restTemplate.getForObject(apiUrl, Product.class);

        if (apiProduct != null) {
            product.setDescription(apiProduct.getDescription());
            product.setPrice(apiProduct.getPrice());
            product.setRating(apiProduct.getRating());
            product.setStock(apiProduct.getStock());
            product.setSku(apiProduct.getSku());
            product.setWeight(apiProduct.getWeight());
        }

        return productRepository.save(product);
    }

    // Atualizar um produto
    public Product update(Long id, Product product) {
        Optional<Product> existingProduct = productRepository.findById(id);
        if (existingProduct.isPresent()) {
            product.setId(id);
            return productRepository.save(product);
        }
        throw new RuntimeException("Product not found");
    }

    // Excluir um produto
    public void delete(Long id) {
        productRepository.deleteById(id);
    }

    // Ressincronizar dados do produto pela API externa
    public Product resyncProduct(Long id) {
        Optional<Product> product = productRepository.findById(id);
        if (product.isPresent()) {
            return save(product.get());
        }
        throw new RuntimeException("Product not found");
    }
}
